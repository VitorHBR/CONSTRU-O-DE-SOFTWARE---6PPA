
document.addEventListener("DOMContentLoaded", function() {
    alert('exibiu')
})

function carregarProduto() {

    //fetch('/json')
    //.then
}